#ifdef _MSC_VER
#pragma comment(linker, "/SUBSYSTEM:windows /ENTRY:mainCRTStartup")
#endif


#include "GL/glew.h"

#include "../lib/glm/glm.hpp"
#include "../lib/glm/gtc/matrix_transform.hpp"
#include <fstream>
#include <sstream>
#include <iostream>
#include <vector>
#include "../lib/glfw/glfw3.h"

#include "../project/Buffer.h"
#include "../project/Shader.h"

#define SCREEN_WIDTH 800
#define SCREEN_HEIGHT 600

bool Initialize()
{ 
	if (glewInit() != GLEW_OK) // Returns 0 if suceess, must be called after setting openGL context - glfwMakeContextCurrent(win)
	{
		printf("Failed to initialize glew");
		return false;
	}

	// Enable depth test
	glEnable(GL_DEPTH_TEST);

	// Enable scissor test
	glEnable(GL_SCISSOR_TEST);

	return true;
}

std::string GetStringFromFile(const std::string& fileName)
{
	std::ifstream stream(fileName.c_str(), std::ios_base::binary);
	if (!stream)
	{
		std::cerr << "ERROR: Could not open file " << fileName << std::endl;
		return "";
	}
	std::stringstream sstream;
	sstream << stream.rdbuf();
	std::string fileContents = sstream.str();
	return fileContents;
}

int main() {

	// Init glfw
	if (!glfwInit()) 
	{
		std::cout << "could not initialize glfw" << std::endl;
		return -1;
	}

	// Create window
	//glfwWindowHint(GLFW_RESIZABLE, false);
	glfwWindowHint(GLFW_SAMPLES, 8);
	GLFWwindow* win = glfwCreateWindow(SCREEN_WIDTH, SCREEN_HEIGHT, "", nullptr, nullptr);
	if (!win) 
	{
		std::cout << "could not create opengl window" << std::endl;
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(win);

	// Used to define the rectangular region where rendered fileContents will be displayed
	glViewport(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);

	// Used to define a sub-section of the screen that should be rendered - for UI?
	glScissor(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT); 

	if (!Initialize())
	{
		return -1;
	}

	glfwSetWindowTitle(win, "3D Programming Assignment #1");

	// Create shader object with the vertex and fragment shaders
	std::string vertexShaderPath = "data/vertex.glsl";
	std::string fragmentShaderPath = "data/fragment.glsl";
	Shader shader = Shader(GetStringFromFile(vertexShaderPath), GetStringFromFile(fragmentShaderPath));

	// Use the compiled shader
	shader.Use();


	// Setup Buffer
	std::vector<Vertex> vertices = // Triangle vertices
	{
		Vertex(glm::vec3(0,0.5f,0),glm::vec3(1,1,1)),
		Vertex(glm::vec3(0.5f,-0.5f,0),glm::vec3(1,1,1)),
		Vertex(glm::vec3(-0.5f,-0.5f,0),glm::vec3(1,1,1)),
	};

	// Setup indices
	std::vector<uint16_t> indices = // Assigns an index to each triangle vertex
	{
		0, 1, 2
	};

	Buffer* buffer = new Buffer(vertices, indices);

	float worldRotation = 0.0f; // Initial rotation

	// Model-View-Projection matrix
	glm::mat4 mvp;
	glm::mat4 modelMatrix;
	glm::mat4 viewMatrix = glm::lookAt(
		glm::vec3(0.0f, 0.0f, 6.0f), // Camera position
		glm::vec3(0.0f, 0.0f, 0.0f), // Look target
		glm::vec3(0.0f, 1.0f, 0.0f)); // Up vector normalized
	glm::mat4 projectionMatrix;

	// Main loop
	float angle = 0;
	double lastTime = glfwGetTime();
	while (!glfwWindowShouldClose(win) && !glfwGetKey(win, GLFW_KEY_ESCAPE)) 
	{
		glClearColor(0, 0, 0, 0);
		glClear(GL_COLOR_BUFFER_BIT);
		glClear(GL_DEPTH_BUFFER_BIT);
		glClear(GL_STENCIL_BUFFER_BIT);
		// Get delta time
		float deltaTime = static_cast<float>(glfwGetTime() - lastTime);
		lastTime = glfwGetTime();

		// Get window size
		int screenWidth, screenHeight;
		glfwGetWindowSize(win, &screenWidth, &screenHeight);

		// Rendering the triangles
		worldRotation += 32.0f * deltaTime;

		if (worldRotation > 360.0f)
		{
			worldRotation -= 360.0f;
		}
		projectionMatrix = glm::perspective(glm::radians(60.0f), static_cast<float>(SCREEN_WIDTH) / static_cast<float>(SCREEN_HEIGHT), 0.1f, 100.0f);

		for (int i = 0; i >= -6; i = i - 3)
		{
			for (int j = -3; j < 6; j = j + 3)
			{
				modelMatrix = glm::mat4(1.0f);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(j, 2, i)); // Translated upwards to see center triangles
				modelMatrix = glm::rotate(modelMatrix, glm::radians(worldRotation), glm::vec3(0.0f, 1.0f, 0.0f)); // Rotate along the y axis - up vector
				mvp = projectionMatrix * viewMatrix * modelMatrix;
				shader.SetMatrix(shader.GetLocation("mvp"), mvp);
				buffer->Draw(shader);
			}
		}

		// Refresh screen
		glfwSwapBuffers(win);
		glfwPollEvents();
	}

	// shutdown
	glfwTerminate();
}