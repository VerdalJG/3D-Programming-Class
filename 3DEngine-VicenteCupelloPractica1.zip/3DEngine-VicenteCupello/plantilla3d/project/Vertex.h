#pragma once

#include "../lib/glm/vec3.hpp"

struct Vertex
{
	Vertex(const glm::vec3& position, const glm::vec3& color)
		: position(position), color(color) {}

	// Vertex position
	glm::vec3 position;
	glm::vec3 color;
};