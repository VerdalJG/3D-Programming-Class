#pragma once
#include "GlobalIncludes.h"

class Buffer;
class Shader;

class Mesh
{
public:
	void AddBuffer(const SharedPtr<Buffer>& buffer, const SharedPtr<Shader>& shader = nullptr);
	void Draw();

private: 
	std::vector<std::pair<SharedPtr<Buffer>, SharedPtr<Shader>>> meshBuffers;

public:
	size_t GetNumBuffers() const { return meshBuffers.size(); }
	const SharedPtr<Buffer>& GetBuffer(size_t index) { return meshBuffers[index].first; }
};

