#include "Mesh.h"
#include "Shader.h"
#include "State.h"
#include "Buffer.h"
#include <iostream>

void Mesh::AddBuffer(const SharedPtr<Buffer>& buffer, const SharedPtr<Shader>& shader)
{
	meshBuffers.push_back(std::make_pair<const SharedPtr<Buffer>&, const SharedPtr<Shader>&>(buffer, shader));
}

void Mesh::Draw()
{
	for (auto& buffer : meshBuffers)
	{
		Shader* shader;
		if (buffer.second.get())
		{
			shader = buffer.second.get();
			shader->Use();
		}
		else
		{
			shader = State::defaultShader.get();
			shader->Use();
		}

		glm::mat4 mvpMatrix = State::projectionMatrix * State::viewMatrix * State::modelMatrix;
		shader->SetMatrix(shader->GetLocation("mvp"), mvpMatrix);
		buffer.first->Draw(*shader);
	}
}
